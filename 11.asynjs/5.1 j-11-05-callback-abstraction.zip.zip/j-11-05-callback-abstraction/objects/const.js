const person = {
    age: 27
}

person.age = 28
// person = {}

console.log(person)