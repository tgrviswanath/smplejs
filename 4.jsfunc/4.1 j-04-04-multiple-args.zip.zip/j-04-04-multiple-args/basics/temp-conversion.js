let fahrenheit = 50 // 0c - 273.15k
let celsius = (fahrenheit - 32) * 5 / 9
let kelvin = (fahrenheit + 459.67) * 5 / 9

console.log(celsius)
console.log(kelvin)